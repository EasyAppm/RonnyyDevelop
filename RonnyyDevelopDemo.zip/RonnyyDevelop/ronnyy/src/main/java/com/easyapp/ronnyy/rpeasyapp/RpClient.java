package com.easyapp.ronnyy.rpeasyapp;

   /*

Link orginal
https://trenduhd.xyz/player_api.php?username=Ronnyy&password=root@2424

Link da api uso próprio nossa - login
https://rpeasyapp.xyz/api/v3/auth?@=user_info&v3=Sandro&user=Ronnyy&pass=root@2424

Link atual  categoria canal
Api nova
https://rpeasyapp.xyz/api/v3/auth?@=get_live&v3=Sandro&user=Ronnyy&pass=root@2424

Link atual categoria filmes
https://trenduhd.xyz/player_api.php?username=Ronnyy&password=root@2424&action=get_vod_categories

Api nova
https://rpeasyapp.xyz/api/v3/auth?@=get_vod&v3=Sandro&user=Ronnyy&pass=root@2424

Link atual api séries
https://trenduhd.xyz/player_api.php?username=Ronnyy&password=root@2424&action=get_series_categories

Api nova séries
https://rpeasyapp.xyz/api/v3/auth?@=get_series&v3=Sandro&user=Ronnyy&pass=root@2424


https://rpeasyapp.xyz/api/v3/auth?@=user_info&v3=Sandro&user=Ronnyy&pass=root@2424

@=ACAO DO GET
v3=MESMO TOKEN DO api/v2/auth
&user=USUAIRO IPTV
&pass=SENHA IPTV

@=user_info  #DADOS DE LOGIN
@=get_live  #CategoriaTv
@=get_vod  #Categoria Filmes
@=get_series  #Categoria Series*/

import com.http.ceas.core.HttpConnection;
import com.http.ceas.core.annotation.Headers;
import com.http.ceas.core.annotation.Insert;
import com.http.ceas.core.annotation.InsertionType;
import com.http.ceas.core.annotation.Params;
import com.http.ceas.core.annotation.verbs.GET;

public interface RpClient {
    
    @Insert(InsertionType.BASE_URL)
    String BASE_URL = "https://rpeasyapp.xyz/api";
    
    @GET("v3/auth")
    @Params({"@:user_info", "v3:{0}", "user:{1}", "pass:{2}"})
    @Headers({"RPEASYAPP:{3}"})
    HttpConnection login(String auth, String user, String password, String token);
    
    @GET("v2/auth/update")
    @Params({"@:{0}"})
    @Headers({"RPEASYAPP:{1}"})
    HttpConnection banner(String name, String token);
    
    @GET("v2/auth/updatetk")
    @Params({"@:{0}"})
    @Headers({"RPEASYAPP:{1}"})
    HttpConnection changeCipher(String name, String token);
    
}
